﻿namespace Military_Elite.IO.Interfaces
{
    public interface IReader
    {
        string ReadLine();
    }
}
