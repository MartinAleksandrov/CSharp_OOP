﻿namespace Military_Elite.Core.Interfaces
{
    public interface IEngine 
    {
        void Run();
    }
}
