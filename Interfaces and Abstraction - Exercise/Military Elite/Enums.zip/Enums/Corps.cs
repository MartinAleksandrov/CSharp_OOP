﻿namespace Military_Elite.Enums
{
    public enum Corps
    {
        Airforces,
        Marines
    }
}
