﻿namespace Military_Elite.Enums
{
    public enum MissionState
    {
        inProgress,
        Finished
    }
}
