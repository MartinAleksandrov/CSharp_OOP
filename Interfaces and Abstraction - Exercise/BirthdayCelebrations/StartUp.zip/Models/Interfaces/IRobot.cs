﻿namespace BirthdayCelebrations.Models.Interfaces
{
    public interface IRobot
    {
        string Model { get; }
        string RobotId { get; }
    }
}
