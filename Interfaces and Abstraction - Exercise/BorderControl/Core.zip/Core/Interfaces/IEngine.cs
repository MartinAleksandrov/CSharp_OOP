﻿
namespace BorderControl.Core.Interfaces
{
    using Interfaces;
    public interface IEngine
    {
        void Run();
    }
}
