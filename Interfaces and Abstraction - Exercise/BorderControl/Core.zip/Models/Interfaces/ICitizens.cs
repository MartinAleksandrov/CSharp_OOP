﻿namespace BorderControl.Models.Interfaces
{
    public interface ICitizens
    {
        string Name { get; }
        int Age { get; }

        string CitizneId { get; }
    }
}
